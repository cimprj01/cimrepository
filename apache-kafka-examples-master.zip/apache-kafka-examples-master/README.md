# Spring Kafka Tutorials and Examples
## spring-kafka-example
[Spring Kafka Tutorial](http://howtoprogram.xyz/2016/09/23/spring-kafka-tutorial/)
## spring-kafka-multi-threaded-consumption
[Spring Kafka - Multi-threaded Message Consumption](http://howtoprogram.xyz/2016/09/25/spring-kafka-multi-threaded-message-consumption/)